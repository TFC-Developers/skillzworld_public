Put the concmaporb.mdl in your tfc/models folder.

The model was made by Watch.
Watch runs the [FM] Fun Server @ 213.208.119.251:27055.


