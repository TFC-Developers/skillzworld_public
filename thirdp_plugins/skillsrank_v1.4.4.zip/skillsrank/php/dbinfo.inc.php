<?
$host="";
$username="";
$password="";
$database="";
?> 